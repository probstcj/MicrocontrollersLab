/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

volatile int enc_flag = 0;
volatile int btn_flag = 0;

const uint8 group_address[13][5] = {
    {0x11,0x11,0x11,0x11,0x11},
    {0x22,0x22,0x22,0x22,0x22},
    {0x33,0x33,0x33,0x33,0x33},
    {0x44,0x44,0x44,0x44,0x44},
    {0x55,0x55,0x55,0x55,0x55},
    {0x66,0x66,0x66,0x66,0x66},
    {0x77,0x77,0x77,0x77,0x77},
    {0x88,0x88,0x88,0x88,0x88},
    {0x99,0x99,0x99,0x99,0x99},
    {0xAA,0xAA,0xAA,0xAA,0xAA},
    {0xBB,0xBB,0xBB,0xBB,0xBB},
    {0xCC,0xCC,0xCC,0xCC,0xCC},
    {0xDD,0xDD,0xDD,0xDD,0xDD}
    
};

const uint8 group_channel[13] = {
    0x10, //16
    0x18, //24
    0x20, //32
    0x28, //40
    0x30, //48
    0x38, //56
    0x40, //64
    0x48, //72
    0x50, //80
    0x58, //88
    0x60, //96
    0x68, //102
    0x70  //110
};

/*****************************************************************************

XXX: TODO Transmitter()

This function puts the NRF24 in TX mode. It should:
- Set 15 retransmissions with a 4000 us delay between each
- Set the data rate to 250 kbps at maximum power level
- Set the payload size to be fixed at 16 bytes
- Ensure auto-acknowledge is turned on for P0 & P1
- Ensure 2-byte CRCs for the auto-acknowledges
- Ensure the data pipes are on
- Ensure the NRF24 is in TX mode and powered up
- Set the correct RF channel based on the input group
- Set the correct TX_ADDR, RX_ADDR_P0, for the target group
- Clear the NRF24 status register

Inputs:
    - int group: An integer representing the group to which the message is
                 directed. This will be used to set the correct address
                 and channel.
               
Outputs:
    - None

*****************************************************************************/
void Transmitter(int group)
{
    
}

/*****************************************************************************

XXX: TODO Receiver()

This function puts the NRF24 in RX mode. It should:
- Set 15 retransmissions with a 4000 us delay between each
- Set the data rate to 250 kbps at maximum power level
- Set the payload size to be fixed at 16 bytes
- Ensure auto-acknowledge is turned on for P0 & P1
- Ensure 2-byte CRCs for the auto-acknowledges
- Ensure the data pipes are on
- Ensure the NRF24 is in RX mode and powered up
- Set the correct RF channel
- Set the correct TX_ADDR, RX_ADDR_P0, and RX_ADDR_P1
- Clear the NRF24 status register

Inputs:
    - None
               
Outputs:
    - None

*****************************************************************************/
void Receiver(void)
{
    
}

/*****************************************************************************

XXX: TODO SendMessage()

This function should send the input message to the target group.
It should:
    - Put the NRF24 in TX mode by calling the Transmitter() function
    - Transmit the message
    - Wait for IRQ to go low
    - Validate whether it was sent correclty using the STATUS register
    - Put the NRF24 back in Receive mode

Inputs:
    - uint8 * message: Where the 16 byte message is stored
    - int group: The target group that should receive the message
               
Outputs:
    - 0 if message is sent correctly
    - 1 if message isn't sent correctly

*****************************************************************************/
int SendMessage(uint8 * message, int group)
{
    int error = 0;
    
    // Put the NRF24 in transmitter mode  
    Transmitter(group);
    
    //XXX: TODO Send payload and check result
    
    // Put the NRF24 in receiver mode again
    Receiver();
    
    return error;
}



int main(void)
{
    uint8 command[16];
    int target = 0;
    int brightness = 0;
    int color_sel = 0;
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    LCD_Start();
    SPI_Start();
    PWM_Start();
    PWM_WritePeriod(99); //Using a period of 99 gives an output rate of 1KHz
    PWM_WriteCompare(0); //It also maps perfectly to a 0-100 duty cycle!
    PWM_SEL_Write(0);
    ENC_ISR_Start();
    BTN_ISR_Start();
    
    CyDelay(100);
    
    Receiver();
    
    
    for(;;)
    {
        /********************************************************************* 
        This block of code selects the target group.
             The encoder is used to cycle through the
             13 possible groups until the button is pressed
        *********************************************************************/
        
        target = 0; //Initialize target group to 0
        
        // Here we wait for the button to be pressed
        while (btn_flag == 0)
        {
            if (NRF24_IRQ_Read() == 0)
            {
                // There's a message for us!
                // XXX:TODO Get the message and set the right LED with
                //          the correct duty cycle
            }
            
            //XXX: TODO Get encoder direction and update LCD with
            //     group number
            
            
        }
        btn_flag = 0;
        
        
        /********************************************************************* 
             This block of code selects the target LED color.
             The encoder is used to cycle through the
             R, G, B, or Y until the button is pressed
        *********************************************************************/        
        color_sel = 0;
        while(btn_flag == 0)
        {
            if (NRF24_IRQ_Read() == 0)
            {
                // There's a message for us!
                // XXX:TODO Get the message and set the right LED with
                //          the correct duty cycle
            }
            
            //XXX: TODO Get encoder direction and update LCD with
            //     correct color            
        }
        btn_flag = 0;
        
        /********************************************************************* 
        This block of code selects the target LED brigthness/PWM duty cycle.
             The encoder is used to cycle down to 0 and up to 100,
             incrementing or decrementing once per click, until the
             button is pressed.
        *********************************************************************/              
        brightness = 50;
        while(btn_flag == 0)
        {
            if (NRF24_IRQ_Read() == 0)
            {
                // There's a message for us!
                // XXX:TODO Get the message and set the right LED with
                //          the correct duty cycle
            }
            
            //XXX: TODO Get encoder direction and update LCD with
            //     correct brightness value                
        }
        btn_flag = 0;
        
        // Now that we have valid input, send it to the target group.
        SendMessage(command, target);
        
    }
}

/* [] END OF FILE */
